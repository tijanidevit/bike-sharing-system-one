<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Eduministers extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('eduministers_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'Eduministers API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }
    function login_post()
    {

        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');


        if ($this->form_validation->run() === FALSE) {
            $this->response([
                'status' => "failed",
                'message' => "Provide email and password.",
                'status_code' => $this->status_code['badRequest'],
                'data' => []
            ], $this->status_code['badRequest']);
        } else {
            $credentials = array(
                'email' => $this->input->post('email'),
                'password' => encrypt($this->input->post('password'))
            );
            $result = $this->eduministers_model->get_login_info($credentials);
            $this->response($result, $result['status_code']);
        }
    }

    function register_post()
    {
        try {
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('last_name', 'Last name', 'required');
            $this->form_validation->set_rules('other_names', 'Other Names', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
            if ($this->form_validation->run() === FALSE) {
                $this->response([
                    'status' => "failed",
                    'message' => "One or more required data is missing.",
                    'status_code' => $this->status_code['badRequest'],
                    'data' => []
                ], $this->status_code['badRequest']);
            } else {
                $friconn_id = generate_id() . $this->eduministers_model->get_last_user_id();
                $details = array(
                    "friconn_id" => $friconn_id,
                    "verification_code" => rand(111111, 999999),
                    "role_id" => $this->fn_model->get_user_role_id('eduminister'),
                    "last_name" => $this->input->post('last_name'),
                    "other_names" => $this->input->post('other_names'),
                    "email" => $this->input->post('email'),
                    "password" => encrypt($this->input->post('password'))
                );

                if ($this->fn_model->check_user_email($details['email'])) {
                    $this->response([
                        'status' => 'error',
                        'message' => 'The email is already associated with another account.',
                        'status_code' => $this->status_code['forbidden']
                    ], $this->status_code['forbidden']);
                } else {
                    send_HTML_email($this, 'Testing', 'testing', $details['email']); //come back to this
                    $response = $this->eduministers_model->create_account($details);
                    $this->response($response, $response['status_code']);
                }
            }
        } catch (\Throwable $th) {
            $this->response([
                'status' => 'error',
                'message' => "Opps! The server has encountered a temporary error. Please try again later",
                'status_code' => $this->status_code['internalServerError']
            ], $this->status_code['internalServerError']);
        }
    }

    function profile_get($friconn_id = '')
    {
        if (!$friconn_id) {
            $eduministers = $this->eduministers_model->get_eduministers();
            return $this->response([
                'status' => "success",
                'message' => "Eduministers fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduministers
            ], $this->status_code['ok']);
        }
        else{
            $eduminister = $this->eduministers_model->get_eduminister($friconn_id);
            if ($eduminister == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Eduminister not found or not an eduminister.",
                    'status_code' => $this->status_code['notFound'],
                    'data' => $eduminister
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Eduminister fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduminister
            ], $this->status_code['ok']);
        }
    }
    function profile_post()
    {
        $this->form_validation->set_rules('employment_status_id', 'Employment Status', 'required');
        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('linked_in_url', 'LinkedIn url', 'required');
        $this->form_validation->set_rules('state_id', 'State', 'required');
        $this->form_validation->set_rules('gender_id', 'Gender', 'required');
        $this->form_validation->set_rules('dob', 'Date of birth', 'required');
        $this->form_validation->set_rules('phone', 'Phone Number', 'required');
        $this->form_validation->set_rules('points', 'Points', 'required');
        $this->form_validation->set_rules('bio', 'Bio', 'required');
        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "failed",
                'message' => "All inputs are required.",
                'status_code' => $this->status_code['badRequest'],
                'data' => []
            ], $this->status_code['badRequest']);
        }

        $profile = [
            'friconn_id' => $this->input->post('friconn_id'),
            'employment_status_id' => $this->input->post('employment_status_id'),
            'dob' => $this->input->post('dob'),
            'phone' => $this->input->post('phone'),
            'points' => $this->input->post('points'),
            'gender_id' => $this->input->post('gender_id'),
            'bio' => $this->input->post('bio'),
            'linked_in_url' => $this->input->post('linked_in_url'),
            'state_id' => $this->input->post('state_id'),
        ];

        $eduminister = $this->fn_model->get_user_via_friconn_id($profile['friconn_id']);
        $role_id = $this->fn_model->get_user_role_id('eduminister');

        if (! $eduminister ) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister not found.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }

        if ($eduminister['role_id'] != $role_id) {
            return $this->response([
                'status' => "error",
                'message' => "User not an eduminister.",
                'status_code' => $this->status_code['unauthorized'],
            ], $this->status_code['unauthorized']);
        }

        if ($this->eduministers_model->update_eduminister_profile($profile)) {
            return $this->response([
                'status' => "success",
                'message' => "Eduminister profile updated successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduminister
            ], $this->status_code['ok']);
        }

        return $this->response([
            'status' => "error",
            'message' => "Unable to update eduminister profile.",
            'status_code' => $this->status_code['badRequest'],
            'data' => $eduminister
        ], $this->status_code['badRequest']);    
    }

    function points_get($friconn_id)
    {
        $eduminister_points = $this->eduministers_model->get_eduminister_points($friconn_id);
        if ($eduminister_points == null) {
            return $this->response([
                'status' => "error",
                'message' => "Unable to fetch eduminister points.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }
        return $this->response([
            'status' => "success",
            'message' => "Eduminister points fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $eduminister_points
        ], $this->status_code['ok']);
    }

    function points_post()
    {

        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('points', 'Points', 'required');
        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "failed",
                'message' => "All inputs are required.",
                'status_code' => $this->status_code['badRequest'],
                'data' => []
            ], $this->status_code['badRequest']);
        }

        $data = [
            'friconn_id' => $this->input->post('friconn_id'),
            'points' => $this->input->post('points')
        ];
        $eduminister = $this->eduministers_model->get_eduminister($data['friconn_id']);
        if ($eduminister == null) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister not found or not an eduminister.",
                'status_code' => $this->status_code['notFound']
            ], $this->status_code['notFound']);
        }

        $update_point = $this->eduministers_model->update_eduminister_points($data);
        if (! $update_point) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister points not updated.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        return $this->response([
            'status' => "success",
            'message' => "Eduminister points updated successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $update_point
        ], $this->status_code['ok']);
    }

    function payouts_get($friconn_id = '')
    {
        if ($friconn_id) {
            $eduminister_payouts = $this->eduministers_model->get_eduminister_payouts($friconn_id);
            if ($eduminister_payouts == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Eduminister has no payouts history.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Eduminister payouts history fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduminister_payouts
            ], $this->status_code['ok']);
        }
        else{
            $eduminister_payouts = $this->eduministers_model->get_eduministers_payouts();
            if ($eduminister_payouts == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Eduministers have no payouts history.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Eduministers payouts history fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduminister_payouts
            ], $this->status_code['ok']);
        }
    }

    function payouts_post()
    {
        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('amount', 'Amount', 'required');
        $this->form_validation->set_rules('deducted_points', 'Deducted Points', 'required');
        $this->form_validation->set_rules('conversion_rate_id', 'Conversion Rate ID', 'required');
        $this->form_validation->set_rules('points_balance', 'Points Balance', 'required');
        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "failed",
                'message' => "All inputs are required.",
                'status_code' => $this->status_code['badRequest'],
                'data' => []
            ], $this->status_code['badRequest']);
        }

        $data = [
            'friconn_id' => $this->input->post('friconn_id'),
            'deducted_points' => $this->input->post('deducted_points'),
            'amount' => $this->input->post('amount'),
            'conversion_rate_id' => $this->input->post('conversion_rate_id'),
            'points_balance' => $this->input->post('points_balance'),
        ];

        $eduminister = $this->eduministers_model->get_eduminister($data['friconn_id']);
        if ($eduminister == null) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister not found or not an eduminister.",
                'status_code' => $this->status_code['notFound']
            ], $this->status_code['notFound']);
        }
        $request_payout = $this->eduministers_model->request_payout($data);
        if (! $request_payout) {
            return $this->response([
                'status' => "error",
                'message' => "Payout request failed.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        //this->edumiminsters_model->update_balance($data);
        //this->$this->eduministers_model->update_eduminister_points($data);
        return $this->response([
            'status' => "success",
            'message' => "Payout request made successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $request_payout
        ], $this->status_code['ok']);
    }

    function courses_get($friconn_id = '')
    {
        if ($friconn_id) {
            $eduminister_courses = $this->eduministers_model->get_eduminister_courses($friconn_id);
            if ($eduminister_courses == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Eduminister has no course added.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Eduminister courses fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduminister_courses
            ], $this->status_code['ok']);
        }
        else{
            $eduminister_courses = $this->eduministers_model->get_eduministers_courses($friconn_id);
            if ($eduminister_courses == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Eduministers have no courses added.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Eduministers courses fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $eduminister_courses
            ], $this->status_code['ok']);
        }
    }

    function courses_post()
    {
        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('course_id', 'course_id', 'required');
        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "failed",
                'message' => "All inputs are required.",
                'status_code' => $this->status_code['badRequest'],
                'data' => []
            ], $this->status_code['badRequest']);
        }

        $data = [
            'friconn_id' => $this->input->post('friconn_id'),
            'course_id' => $this->input->post('course_id'),
        ];

        $role_id = $this->fn_model->get_user_role_id('eduminister');
        $user = $this->fn_model->get_user_via_friconn_id($data['friconn_id']);

        if ($user['role_id'] !== $role_id) {
            return $this->response([
                'status' => "error",
                'message' => "User not an eduminister.",
                'status_code' => $this->status_code['unauthorized'],
            ], $this->status_code['unauthorized']);
        }

        if ($this->eduministers_model->check_eduminister_course($data)) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister already added this course.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);
        }
        $course = $this->eduministers_model->add_eduminister_course($data);
        if (!$course) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister course not added.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);
        }

        return $this->response([
            'status' => "success",
            'message' => "Eduminister course added successfully.",
            'status_code' => $this->status_code['created'],
            'data' => $course,
        ], $this->status_code['created']);
    }


    function questions_get($friconn_id)
    {
        $role_id = $this->fn_model->get_user_role_id('eduminister');
        $user = $this->fn_model->get_user_via_friconn_id($friconn_id);

        if ($user['role_id'] !== $role_id) {
            return $this->response([
                'status' => "error",
                'message' => "User not an eduminister.",
                'status_code' => $this->status_code['unauthorized'],
            ], $this->status_code['unauthorized']);
        }
        
        $eduminister_questions = $this->eduministers_model->get_eduminister_questions($friconn_id);
        if ($eduminister_questions == null) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister has no question added.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }
        return $this->response([
            'status' => "success",
            'message' => "Eduminister questions fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $eduminister_questions
        ], $this->status_code['ok']);
        
    }
    
    function answers_get($friconn_id)
    {
        $role_id = $this->fn_model->get_user_role_id('eduminister');
        $user = $this->fn_model->get_user_via_friconn_id($friconn_id);

        if ($user['role_id'] !== $role_id) {
            return $this->response([
                'status' => "error",
                'message' => "User not an eduminister.",
                'status_code' => $this->status_code['unauthorized'],
            ], $this->status_code['unauthorized']);
        }

        $eduminister_answers = $this->eduministers_model->get_eduminister_answers($friconn_id);
        if ($eduminister_answers == null) {
            return $this->response([
                'status' => "error",
                'message' => "Eduminister has no answer added.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }
        return $this->response([
            'status' => "success",
            'message' => "Eduminister answers fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $eduminister_answers
        ], $this->status_code['ok']);
        
    }
}