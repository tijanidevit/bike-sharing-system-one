<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Payments extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('payments_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'payments API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }

    function new_post()
    {
        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('plan_id', 'Plan ID', 'required');
        $this->form_validation->set_rules('amount', 'Amount', 'required');
        $this->form_validation->set_rules('txt_ref', 'Txt Ref', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "All input boxes required.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $points = $this->fn_model->get_plan_points($this->input->post('plan_id')); 
        $payment_data = array(
            'friconn_id' => $this->input->post('friconn_id'),
            'amount' => $this->input->post('amount'),
            'txt_ref' => $this->input->post('txt_ref'),
            'plan_id' => $this->input->post('plan_id'),
            'points' => $points
        );

        if ($this->payments_model->check_payment_existence($payment_data)) {
            return $this->response([
                'status' => "error",
                'message' => "Payment already added.",
                'status_code' => $this->status_code['badRequest']
            ], $this->status_code['badRequest']);
        }

        $payment = $this->payments_model->add_payment($payment_data);
        if ($payment) {
            return $this->response([
                'status' => "success",
                'message' => "Payment added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $payment
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Unable to ask payment.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);

        }
    }

    function view_get($id = '')
    {
        if (!$id) {
            $payments = $this->payments_model->get_payments();
            if ($payments == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No payments asked yet.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Payments fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $payments
            ], $this->status_code['ok']);
        }
        else{
            $payment = $this->payments_model->get_payment($id);
            if ($payment == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Payment not found.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Payment fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $payment
            ], $this->status_code['ok']);
        }
    }
}