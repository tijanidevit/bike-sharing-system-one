<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class faculties extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('faculties_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'faculties API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }
    function new_post()
    {
        $this->form_validation->set_rules('faculty', 'faculty', 'required');
        $this->form_validation->set_rules('faculty_id', 'Faculty ID', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a faculty and provide faculty name.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $faculty_data = array(
            'faculty' => $this->input->post('faculty'),
            'faculty_id' => $this->input->post('faculty_id'),
        );

        if ($this->faculties_model->check_faculty_existence($faculty_data)) {
            return $this->response([
                'status' => "error",
                'message' => "faculty already added.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        $faculty = $this->faculties_model->add_new_faculty($faculty_data);
        if ($faculty) {
            return $this->response([
                'status' => "success",
                'message' => "faculty added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $faculty
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "faculty not added.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);

        }
    }

    function view_get($id = '')
    {
        if ($id) {
            $faculty = $this->faculties_model->get_faculty($id);
            if ($faculty == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "faculty not found.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "faculty fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $faculty
            ], $this->status_code['ok']);
        }
        else{
            $faculties = $this->faculties_model->get_faculties();
            if ($faculties == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No faculties found.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "faculties fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $faculties
            ], $this->status_code['ok']);
        }
    }

    function questions_get($faculty_id)
    {
        $faculty_questions = $this->faculties_model->get_faculty_questions($faculty_id);
        if ($faculty_questions == null) {
            return $this->response([
                'status' => "error",
                'message' => "faculty has no question added.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }
        return $this->response([
            'status' => "success",
            'message' => "faculty questions fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $faculty_questions
        ], $this->status_code['ok']);
        
    }

    function departments_post()
    {
        $this->form_validation->set_rules('department_id', 'Department', 'required');
        $this->form_validation->set_rules('faculty_id', 'Faculty ID', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a faculty and department.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $department_data = array(
            'department_id' => $this->input->post('department_id'),
            'faculty_id' => $this->input->post('faculty_id'),
        );

        if ($this->faculties_model->check_faculty_department_existence($department_data)) {
            return $this->response([
                'status' => "error",
                'message' => "faculty department already added.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        $department = $this->faculties_model->add_new_faculty_department($department_data);
        if ($department) {
            return $this->response([
                'status' => "success",
                'message' => "faculty department added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $department
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "faculty department not added.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);

        }
    }
}