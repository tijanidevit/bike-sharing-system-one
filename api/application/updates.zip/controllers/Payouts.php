<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Payouts extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('payouts_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get($id='')
    {
        if ($id) {
            $payout = $this->payouts_model->get_payout($id);
            if ($payout) {
                return $this->response([
                    'status' => "success",
                    'message' => "Payout fetched successfully.",
                    'data' => $payout,
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "error",
                'message' => "Payout not found.",
                'status_code' => $this->status_code['ok'],
            ], $this->status_code['ok']);
        }
        else{
            $payouts = $this->payouts_model->get_payouts();
            if ($payouts) {
                return $this->response([
                    'status' => "success",
                    'message' => "Payouts fetched successfully.",
                    'data' => $payouts,
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "error",
                'message' => "Payouts not found.",
                'status_code' => $this->status_code['ok'],
            ], $this->status_code['ok']);
        }
    }

    function rate_get($id = '')
    {
        $conversion_rate = 0;
        if ($id) {
            $conversion_rate = $this->fn_model->get_conversion_rate($id);
        }
        else{
            $conversion_rate = $this->fn_model->get_conversion_rate();
        }
        if ($conversion_rate != 0) {
            return $this->response([
                'status' => "success",
                'message' => "Conversion rate fetched successfully.",
                'data' => $conversion_rate,
                'status_code' => $this->status_code['ok'],
            ], $this->status_code['ok']);
        }
        return $this->response([
            'status' => "error",
            'message' => "Conversion Rate not found.",
            'status_code' => $this->status_code['ok'],
        ], $this->status_code['ok']);
    }
}