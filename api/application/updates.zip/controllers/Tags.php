<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Tags extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('tags_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {
        $this->response([
            'status' => 'success',
            'message' => 'tags API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }

    function new_post()
    {
        $this->form_validation->set_rules('tag', 'tag', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please enter a tag.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $tag_data = [
            'tag' => $this->input->post('tag'),
        ];

        if ($this->fn_model->get_tag_via_tag($tag_data['tag'])) {
            return $this->response([
                'status' => "error",
                'message' => "Tag added already successfully.",
                'status_code' => $this->status_code['badRequest']
            ], $this->status_code['badRequest']);
        }

        $tag = $this->fn_model->add_tag($tag_data);
        if ($tag) {
            return $this->response([
                'status' => "success",
                'message' => "Tag added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $tag
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Unable to add tag.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);

        }
    }

    function view_get($slug = '')
    {
        if (!$slug) {
            $tags = $this->tags_model->get_tags();
            if ($tags == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No tags added yet.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "tags fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $tags
            ], $this->status_code['ok']);
        }
        else{
            $tag = $this->tags_model->get_tag($slug);
            if ($tag == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "tag not found.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "tag fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $tag
            ], $this->status_code['ok']);
        }
    }
}