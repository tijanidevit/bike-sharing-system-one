<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Points extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('points_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {
        $this->response([
            'status' => 'success',
            'message' => 'points API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }

    function charges_post()
    {
        $this->form_validation->set_rules('points', 'Points', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please enter a point.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $points_data = [
            'charging_point' => $this->input->post('points'),
        ];

        $points = $this->points_model->add_charging_points($points_data);
        if ($points) {
            return $this->response([
                'status' => "success",
                'message' => "Points added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $points
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Unable to add Points.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);

        }
    }

    function charges_get($id = '')
    {
        if (!$id) {
            $points = $this->points_model->get_all_charging_points();
            if ($points == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No points added yet.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "points fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $points
            ], $this->status_code['ok']);
        }
        else{
            $point = $this->points_model->get_single_charging_points($id);
            if ($point == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "point not found.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "point fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $point
            ], $this->status_code['ok']);
        }
    }


    function earnings_post()
    {
        $this->form_validation->set_rules('points', 'Points', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please enter a point.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $points_data = [
            'earning_point' => $this->input->post('points'),
        ];

        $points = $this->points_model->add_earning_points($points_data);
        if ($points) {
            return $this->response([
                'status' => "success",
                'message' => "Points added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $points
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Unable to add Points.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);

        }
    }

    function earnings_get($id = '')
    {
        if (!$id) {
            $points = $this->points_model->get_all_earning_points();
            if ($points == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No points added yet.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "points fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $points
            ], $this->status_code['ok']);
        }
        else{
            $point = $this->points_model->get_single_earning_points($id);
            if ($point == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "point not found.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "point fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $point
            ], $this->status_code['ok']);
        }
    }
}