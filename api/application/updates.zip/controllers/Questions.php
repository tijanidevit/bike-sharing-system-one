<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Questions extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('questions_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'Questions API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }

    function new_post()
    {
        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('course_id', 'Course ID', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('question', 'Question', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "All input boxes required.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $question_data = array(
            'friconn_id' => $this->input->post('friconn_id'),
            'course_id' => $this->input->post('course_id'),
            'subject' => $this->input->post('subject'),
            'question' => $this->input->post('question'),
            'slug' => url_title($this->input->post('subject'), 'dash', TRUE).time(),
        );
        $tags = $this->input->post('tags');
        
        $question = $this->questions_model->ask_question($question_data);
        if ($question) {

            $tags = $this->input->post('tags');
            
            if (count($tags) > 0) {
                    $tags_data = [
                    'question_id' => $question['id'],
                    'tags' => $tags,
                ];
                $question['tags'] = $this->questions_model->add_question_tags($tags_data);
            }
            
           

            return $this->response([
                'status' => "success",
                'message' => "Question asked successfully. Await an answer soon",
                'status_code' => $this->status_code['created'],
                'data' => $question
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Unable to ask question.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);

        }
    }

    function view_get($id = '')
    {
        if (!$id) {
            $questions = $this->questions_model->get_questions();
            if ($questions == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No questions asked yet.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Questions fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $questions
            ], $this->status_code['ok']);
        }
        else{
            $question = $this->questions_model->get_question($id);
            if ($question == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Question not found.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Question fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $question
            ], $this->status_code['ok']);
        }
    }

    function answers_get($id)
    {
        if (!$id) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a question.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $question_answers = $this->questions_model->get_question_answers($id);
        if ($question_answers == null) {
            return $this->response([
                'status' => "error",
                'message' => "No answer submitted for this question.",
                'status_code' => $this->status_code['ok'],
            ], $this->status_code['ok']);
        }

        // if (deductUserPoints or UpdateUserPoints) {
        //     # code... I think it should be update, the points deduction and calculation should be done via FE
        // then we can return success response
        // }

        return $this->response([
            'status' => "success",
            'message' => "Question answers fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $question_answers
        ], $this->status_code['ok']);
    }

    function answers_post()
    {

        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('question_id', 'Question ID', 'required');
        $this->form_validation->set_rules('answer', 'answer', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "All input boxes required.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $answer_data = array(
            'friconn_id' => $this->input->post('friconn_id'),
            'question_id' => $this->input->post('question_id'),
            'answer' => $this->input->post('answer'),
        );

        $question_answer = $this->questions_model->add_question_answer($answer_data);
        if (!$question_answer) {
            return $this->response([
                'status' => "error",
                'message' => "Unable to submit answer for this question.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);
        }

        $this->fn_model->set_question_answered($answer_data['question_id']);
        return $this->response([
            'status' => "success",
            'message' => "Answer submitted successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $question_answer
        ], $this->status_code['ok']);
    }
}