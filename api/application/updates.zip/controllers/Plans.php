<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class plans extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('plans_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'plans API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }

    function new_post()
    {
        $this->form_validation->set_rules('plan', 'Plan', 'required');
        $this->form_validation->set_rules('ribbon_value', 'Ribbon Value', 'required');
        $this->form_validation->set_rules('color', 'Color', 'required');
        $this->form_validation->set_rules('points', 'Points', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "All input boxes required.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $plan_data = array(
            'plan' => $this->input->post('plan'),
            'ribbon_value' => $this->input->post('ribbon_value'),
            'color' => $this->input->post('color'),
            'points' => $this->input->post('points'),
            'price' => $this->input->post('price'),
        );

        if ($this->plans_model->check_plan_existence($plan_data)) {
            return $this->response([
                'status' => "error",
                'message' => "Plan already added.",
                'status_code' => $this->status_code['badRequest']
            ], $this->status_code['badRequest']);
        }

        $plan = $this->plans_model->add_plan($plan_data);
        if ($plan) {
            return $this->response([
                'status' => "success",
                'message' => "Plan added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $plan
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Unable to ask plan.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);

        }
    }

    function view_get($id = '')
    {
        if (!$id) {
            $plans = $this->plans_model->get_plans();
            if ($plans == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No plans asked yet.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "plans fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $plans
            ], $this->status_code['ok']);
        }
        else{
            $plan = $this->plans_model->get_plan($id);
            if ($plan == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "plan not found.",
                    'status_code' => $this->status_code['ok'],
                ], $this->status_code['ok']);
            }
            return $this->response([
                'status' => "success",
                'message' => "plan fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $plan
            ], $this->status_code['ok']);
        }
    }

    function features_get($id)
    {
        if (!$id) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a plan.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $plan_features = $this->plans_model->get_plan_features($id);
        if ($plan_features == null) {
            return $this->response([
                'status' => "error",
                'message' => "This plan has no features added.",
                'status_code' => $this->status_code['ok'],
            ], $this->status_code['ok']);
        }

        return $this->response([
            'status' => "success",
            'message' => "Plan features fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $plan_features
        ], $this->status_code['ok']);
    }

    function features_post()
    {

        $this->form_validation->set_rules('plan_id', 'plan ID', 'required');
        $this->form_validation->set_rules('feature', 'feature', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "All input boxes required.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $feature_data = [
            'plan_id' => $this->input->post('plan_id'),
            'feature' => $this->input->post('feature'),
        ];

        if ($this->plans_model->check_plan_feature_existence($feature_data)) {
            return $this->response([
                'status' => "error",
                'message' => "Feature already added to this plan.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        $plan_feature = $this->plans_model->add_plan_feature($feature_data);
        if (!$plan_feature) {
            return $this->response([
                'status' => "error",
                'message' => "Unable to add feature to this plan.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);
        }
        return $this->response([
            'status' => "success",
            'message' => "Feature added successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $plan_feature
        ], $this->status_code['ok']);
    }
}