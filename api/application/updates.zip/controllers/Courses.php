<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Courses extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('courses_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'courses API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }
    function new_post()
    {
        $this->form_validation->set_rules('course', 'Course', 'required');
        $this->form_validation->set_rules('course_code', 'Course Code', 'required');


        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please provide course and course code.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $course_data = array(
            'course' => $this->input->post('course'),
            'course_code' => $this->input->post('course_code'),
        );

        if ($this->courses_model->check_course_existence($course_data)) {
            return $this->response([
                'status' => "error",
                'message' => "Course already added.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        $course = $this->courses_model->add_new_course($course_data);
        if ($course) {
            return $this->response([
                'status' => "success",
                'message' => "Course added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $course
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Course not added.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);

        }
    }

    function view_get($id = '')
    {
        if ($id) {
            $course = $this->courses_model->get_course($id);
            if ($course == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Course not found.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Course fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $course
            ], $this->status_code['ok']);
        }
        else{
            $courses = $this->courses_model->get_courses();
            if ($courses == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No courses found.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Courses fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $courses
            ], $this->status_code['ok']);
        }
    }

    function questions_get($course_id)
    {
        if (!$course_id) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a course.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $course_questions = $this->courses_model->get_course_questions($course_id);
        if ($course_questions == null) {
            return $this->response([
                'status' => "error",
                'message' => "Course has no question added.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }
        return $this->response([
            'status' => "success",
            'message' => "Course questions fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $course_questions
        ], $this->status_code['ok']);
        
    }



    function join_post()
    {
        $this->form_validation->set_rules('friconn_id', 'Friconn ID', 'required');
        $this->form_validation->set_rules('course_id', 'course_id', 'required');
        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "failed",
                'message' => "All inputs are required.",
                'status_code' => $this->status_code['badRequest'],
                'data' => []
            ], $this->status_code['badRequest']);
        }

        $data = [
            'friconn_id' => $this->input->post('friconn_id'),
            'course_id' => $this->input->post('course_id'),
        ];

        if (! $this->fn_model->get_user_course($data['course_id'])) {
            return $this->response([
                'status' => "error",
                'message' => "Course does not exist.",
                'status_code' => $this->status_code['ok'],
            ], $this->status_code['ok']);
        }

        if ($this->courses_model->check_learner_course($data)) {
            return $this->response([
                'status' => "error",
                'message' => "You already added this course.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);
        }
        $course = $this->courses_model->add_learner_course($data);
        if (!$course) {
            return $this->response([
                'status' => "error",
                'message' => "Course not added.",
                'status_code' => $this->status_code['internalServerError'],
            ], $this->status_code['internalServerError']);
        }

        return $this->response([
            'status' => "success",
            'message' => "Course added successfully.",
            'status_code' => $this->status_code['created'],
            'data' => $course
        ], $this->status_code['created']);
    }
}