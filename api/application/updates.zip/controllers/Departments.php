<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Departments extends REST_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('departments_model');
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
        $this->load->library('form_validation');
    }

    function index_get()
    {

        $this->response([
            'status' => 'success',
            'message' => 'Departments API Connected successful.',
            'time_connected' => date('d-M-Y h:i:s'),
            'domain' => base_url()
        ], REST_Controller::HTTP_OK);
    }
    function new_post()
    {
        $this->form_validation->set_rules('department', 'Department', 'required');
        $this->form_validation->set_rules('faculty_id', 'Faculty ID', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a faculty and provide department name.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $department_data = array(
            'department' => $this->input->post('department'),
            'faculty_id' => $this->input->post('faculty_id'),
        );

        if ($this->departments_model->check_department_existence($department_data)) {
            return $this->response([
                'status' => "error",
                'message' => "Department already added.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        $department = $this->departments_model->add_new_department($department_data);
        if ($department) {
            return $this->response([
                'status' => "success",
                'message' => "Department added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $department
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Department not added.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);

        }
    }

    function view_get($id = '')
    {
        if ($id) {
            $department = $this->departments_model->get_department($id);
            if ($department == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "Department not found.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Department fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $department
            ], $this->status_code['ok']);
        }
        else{
            $departments = $this->departments_model->get_departments();
            if ($departments == null) {
                return $this->response([
                    'status' => "error",
                    'message' => "No departments found.",
                    'status_code' => $this->status_code['notFound'],
                ], $this->status_code['notFound']);
            }
            return $this->response([
                'status' => "success",
                'message' => "Departments fetched successfully.",
                'status_code' => $this->status_code['ok'],
                'data' => $departments
            ], $this->status_code['ok']);
        }
    }

    function questions_get($department_id)
    {
        $department_questions = $this->departments_model->get_department_questions($department_id);
        if ($department_questions == null) {
            return $this->response([
                'status' => "error",
                'message' => "department has no question added.",
                'status_code' => $this->status_code['notFound'],
            ], $this->status_code['notFound']);
        }
        return $this->response([
            'status' => "success",
            'message' => "department questions fetched successfully.",
            'status_code' => $this->status_code['ok'],
            'data' => $department_questions
        ], $this->status_code['ok']);
        
    }

    function courses_post()
    {
        $this->form_validation->set_rules('course_id', 'Course', 'required');
        $this->form_validation->set_rules('department_id', 'department ID', 'required');

        if ($this->form_validation->run() === FALSE) {
            return $this->response([
                'status' => "error",
                'message' => "Please select a department and course.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }
        $course_data = array(
            'course_id' => $this->input->post('course_id'),
            'department_id' => $this->input->post('department_id'),
        );

        if ($this->departments_model->check_department_course_existence($course_data)) {
            return $this->response([
                'status' => "error",
                'message' => "Department course already added.",
                'status_code' => $this->status_code['badRequest'],
            ], $this->status_code['badRequest']);
        }

        $course = $this->departments_model->add_new_department_course($course_data);
        if ($course) {
            return $this->response([
                'status' => "success",
                'message' => "Department course added successfully.",
                'status_code' => $this->status_code['created'],
                'data' => $course
            ], $this->status_code['created']);
        }
        else{
            return $this->response([
                'status' => "error",
                'message' => "Department course not added.",
                'status_code' => $this->status_code['conflict'],
            ], $this->status_code['conflict']);

        }
    }
}