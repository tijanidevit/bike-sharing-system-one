<?php
class questions_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }

    public function get_question($slug){
        $this->db->select('*');
        $this->db->where(['slug' => $slug]);
        $this->db->or_where(['id' => $slug]);
        $question = $this->db->get('questions')->row_array();
        if ($question) {

            $user = $this->fn_model->get_user_via_friconn_id($question['friconn_id']);
            $question['user'] = $user['last_name']. ' '.$user['other_names'];

            $course = $this->fn_model->get_user_course($question['course_id']);
            $question['course'] = $course;

            $question['tags'] = $this->get_question_tags($question['id']);
            return $question;
        }
        return null;
    }

    public function get_questions(){
        $this->db->select('*');
        $questions = $this->db->order_by('id','desc')->get('questions')->result();

        if ($questions) {
            foreach ($questions as $question) {
                $user = $this->fn_model->get_user_via_friconn_id($question->friconn_id);
                $question->user = $user['last_name']. ' '.$user['other_names'];

                $course = $this->fn_model->get_user_course($question->course_id);
                $question->course = $course;
            }
            return $questions;
        }
        return null;
    }


    public function ask_question($data){
        if ($this->db->insert('questions',$data)) {
            $question = $this->get_user_last_question($data['friconn_id']);
            return $question;
        }
        return false;
    }

    public function get_user_last_question($friconn_id){
        $this->db->select('*');
        $this->db->where(['friconn_id' => $friconn_id]);
        $question = $this->db->order_by('id', "desc")->limit(1)->get('questions')->row_array();

        if ($question) {
            $course = $this->fn_model->get_user_course($question['course_id']);
            $question['course'] = $course;

            return $question;
        }
        return null;
    }

    public function add_question_tags($data){
        $question_id = $data['question_id'];
        $tags = $data['tags'];
        

        $sn = 0;
        
        foreach ($tags as $tag) {
            $check_tag_existence = $this->fn_model->get_tag_via_tag($tag);
            if ($check_tag_existence != 0) {
                $tag_id = $check_tag_existence['id'];
            }
            else{
                $tag_data =['tag' => $tag];
                $tag_id = $this->fn_model->add_tag($tag_data)['id'];
            }

            $question_tag_data = [
                'tag_id' => $tag_id,
                'question_id' => $question_id,
            ];

            $this->db->insert('question_tags',$question_tag_data);
            if ($sn == 4) {
                break;
            }
            $sn++;
        }
        $question_tags = $this->get_question_tags($question_id);
        return $question_tags;
    }

    public function get_question_tags($question_id){
        $this->db->select('id,question_id,tag_id');
        $this->db->where(['question_id' => $question_id]);
        $question_tags = $this->db->order_by('id', "desc")->get('question_tags')->result();

        if ($question_tags) {
            foreach ($question_tags as $question_tag) {
                $question_tag->tag = $this->fn_model->get_tag_via_id($question_tag->tag_id)['tag'];
            }
            return $question_tags;
        }
        return null;
    }

    public function get_question_answers($id){
        $this->db->select('*');
        $this->db->where(['question_id' => $id]);
        $question_answers = $this->db->order_by('id', "desc")->get('question_answers')->result();

        if ($question_answers) {
 
            foreach ($question_answers as $question_answer) {
                $f_id = $question_answer->friconn_id;
                
                $user = $this->fn_model->get_user_via_friconn_id($f_id);
                $question_answer->user = $user['last_name'].' '.$user['other_names'];
            }
            // $question = $this->get_question($id);
            // $question_answers['question'] = $question['subject'];

            return $question_answers;
        }
        return null;
    }

    public function add_question_answer($data){
        if ($this->db->insert('question_answers',$data)) {
            $question = $this->get_user_last_answer($data['friconn_id']);
            return $question;
        }
        return false;
    }

    public function get_user_last_answer($friconn_id){
        $this->db->select('*');
        $this->db->where(['friconn_id' => $friconn_id]);
        $question_answer = $this->db->order_by('id', "desc")->limit(1)->get('question_answers')->row_array();

        if ($question_answer) {
            $question = $this->get_question($question_answer['question_id']);
            $question_answer['question'] = $question['subject'];

            $user = $this->fn_model->get_user_via_friconn_id($question_answer['friconn_id']);
            $question_answer['user'] = $user['last_name'].' '.$user['other_names'];

            return $question_answer;
        }
        return null;
    }
}
