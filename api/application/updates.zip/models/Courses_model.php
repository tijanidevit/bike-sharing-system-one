<?php
class Courses_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }


    public function add_new_course($data){
        if ($this->db->insert('courses', $data )) {
            $this->db->where(["course" => $data['course']]);
            $course = $this->db->get('courses')->row_array();
            return $course;     
        }
        return false;
    }

    public function check_course_existence($data)
    {
        $this->db->select('id');
        $course = $this->db->get_where('courses',['course' => $data['course']])->num_rows();
        if ($course > 0) {
            return true;
        }
        return false;
    }

    public function get_course($id){
        $this->db->select('*');
        $course = $this->db->get_where('courses',['id' => $id])->row_array();
        if ($course) {
            // $department = $this->fn_model->get_user_department($course['department_id']);
            // $course['department'] = $department['department'];
            return $course;
        }
        return null;
    }

    public function get_courses(){
        $this->db->select('*');
        $courses = $this->db->order_by('id','desc')->get('courses')->result();

        if ($courses) {
            // foreach ($courses as $course) {

            //     $department = $this->fn_model->get_user_department($course->department_id);
            //     $course->department = $department['department'];
            // }
            return $courses;
        }
        return null;
    }

    public function get_course_questions($course_id){
        $this->db->select('*');
        $questions = $this->db->order_by('id','desc')->get_where('questions',['course_id' => $course_id])->result();

        foreach ($questions as $question) {
            $user = $this->fn_model->get_user_via_friconn_id($question->friconn_id);
            $question->learner = $user['last_name']. ' '.$user['other_names'];

            $course = $this->fn_model->get_user_course($question->course_id);
            $question->course = $course;
        }
        if ($questions) {
            return $questions;
        }
        return null;
    }

    

    public function check_learner_course($data){
        $this->db->select('id');
        $this->db->where(['course_id' => $data['course_id'],'friconn_id' =>$data['friconn_id']]);
        $learners_course = $this->db->get('learner_courses')->num_rows();
        if ($learners_course > 0) {
            return true;
        }
        return false;
    }

    public function add_learner_course($data){
        if ($this->db->insert('learner_courses',$data)) {
            $course = $this->get_learner_last_course($data['friconn_id']);
            return $course;
        }
        return false;
    }

    public function get_learner_last_course($friconn_id){
        $this->db->select('*');
        $this->db->where(['friconn_id' => $friconn_id]);
        $learner_course = $this->db->order_by('id', "desc")->limit(1)->get('learner_courses')->row_array();

        if ($learner_course) {
            $course = $this->fn_model->get_user_course($learner_course['course_id']);
            $learner_course['course'] = $course;

            return $learner_course;
        }
        return null;
    }
}
