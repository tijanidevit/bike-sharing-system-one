<?php
class Departments_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }


    public function add_new_department($data){
        if ($this->db->insert('departments', $data )) {
            $this->db->where(["department" => $data['department']]);
            $department = $this->db->get('departments')->row_array();
            return $department;     
        }
        return false;
    }

    public function check_department_existence($data)
    {
        $this->db->select('id');
        $department = $this->db->get_where('departments',['department' => $data['department']])->num_rows();
        if ($department > 0) {
            return true;
        }
        return false;
    }

    public function get_department($id){
        $this->db->select('*');
        $department = $this->db->get_where('departments',['id' => $id])->row_array();
        if ($department) {
            $faculty = $this->fn_model->get_user_faculty($department['faculty_id']);
            $department['faculty'] = $faculty;
            $department['courses'] = $this->get_department_courses($id);
            return $department;
        }
        return null;
    }

    public function get_departments(){
        $this->db->select('*');
        $departments = $this->db->order_by('id','desc')->get('departments')->result();

        foreach ($departments as $department) {

            $faculty = $this->fn_model->get_user_faculty($department->faculty_id);
            $department->faculty = $faculty;
        }
        if ($departments) {
            return $departments;
        }
        return null;
    }

    public function get_department_courses($department_id){
        $this->db->select('*');
        $department_courses = $this->db->order_by('id','desc')->get_where('department_courses',['department_id' => $department_id])->result();
        if ($department_courses) {
            foreach ($department_courses as $department_course) {
                $course = $this->fn_model->get_user_course($department_course->course_id);
                $department_course->course = $course;
            }
            return $department_courses;
        }
        return null;
    }


    public function add_new_department_course($data){
        if ($this->db->insert('department_courses', $data )) {
            $this->db->where(["department_id" => $data['department_id'],"course_id" => $data['course_id']]);
            $department_course = $this->db->get('department_courses')->row_array();
            return $department_course;     
        }
        return false;
    }

    public function check_department_course_existence($data)
    {
        $this->db->select('id');
        $department_course = $this->db->get_where('department_courses',['department_id' => $data['department_id'],'course_id' => $data['course_id']])->num_rows();
        if ($department_course > 0) {
            return true;
        }
        return false;
    }
}
