<?php
class Payouts_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }

    public function get_payout($id){
        $this->db->select('*');
        $payout = $this->db->get_where('eduminister_payouts',['id' => $id])->row_array();
        $user = $this->fn_model->get_user_via_friconn_id($payout['friconn_id']);
        $payout['eduminister'] = $user['last_name']. ' '.$user['other_names'];

        $conversion_rate = $this->fn_model->get_conversion_rate($payout['conversion_rate_id']);
        $payout['naira_per_point'] = $conversion_rate['naira_per_point'];

        if ($payout) {
            return $payout;
        }
        return null;
    }

    public function get_payouts(){
        $this->db->select('*');
        $payouts = $this->db->order_by('id','desc')->get('eduminister_payouts')->result();

        foreach ($payouts as $payout) {
            $user = $this->fn_model->get_user_via_friconn_id($payout->friconn_id);
            $payout->eduminister = $user['last_name']. ' '.$user['other_names'];

            $conversion_rate = $this->fn_model->get_conversion_rate($payout->conversion_rate_id);
            $payout->naira_per_point = $conversion_rate['naira_per_point'];
        }
        if ($payouts) {
            return $payouts;
        }
        return null;
    }
}
