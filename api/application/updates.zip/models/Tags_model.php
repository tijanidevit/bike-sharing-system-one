<?php
class tags_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }

    public function get_tag($slug){
        $this->db->select('*');
        $this->db->where(['tag' => $slug]);
        $this->db->or_where(['id' => $slug]);
        $tag = $this->db->get('tags')->row_array();
        if ($tag) {
            $tag['questions'] = $this->get_tag_questions($tag['id']);
            return $tag;
        }
        return null;
    }

    public function get_tags(){
        $this->db->select('id,tag');
        $tags = $this->db->order_by('id','desc')->get('tags')->result();

        if ($tags) {
            return $tags;
        }
        return null;
    }

    public function get_tag_questions($tag_id){
        $this->db->select('id,tag_id,question_id');
        $this->db->where(['tag_id' => $tag_id]);
        $tag_questions = $this->db->order_by('id', "desc")->get('question_tags')->result();

        if ($tag_questions) {
            foreach ($tag_questions as $tag_question) {
                $tag_question->question = $this->fn_model->get_question_via_id($tag_question->question_id)['subject'];
            }
            return $tag_questions;
        }
        return null;
    }
}
