<?php
class Eduministers_model extends CI_Model
{
    /* 
        @Description Eduministers Model.
    */
        public function __construct()
        {
            $this->load->database();
            $this->load->model('fn_model');
            $this->status_code  = get_response_status_code();
        }

        public function get_login_info($credentials)
        {

            $this->db->where(["email" => $credentials['email']]);
            $user = $this->db->get('users')->row_array();

            if (!$user) {
                return array(
                    'status' => "error",
                    'message' => "Invalid email address",
                    'status_code' => $this->status_code['unauthorized']
                );
            }

            if ($user['password'] !== $credentials['password']) {
                return array(
                    'status' => "error",
                    'message' => "Login failed! Incorrect account password.",
                    'status_code' => $this->status_code['unauthorized']
                );
            }

            if (!$this->fn_model->match_user_with_role($user['role_id'], 'eduminister')) {
                return array(
                    'status' => "error",
                    'message' => "Access Denied! Please login through the right user account.",
                    'status_code' => $this->status_code['unauthorized']
                );
            }


            if ($user['blocked'] === 1) {
                return array(
                    'status' => "error",
                    'message' => "Access Denied! This account is temporarily blocked, please contact our support centre.",
                    'status_code' => $this->status_code['forbidden']
                );
            }
            $eduminister_details = $this->_get_eduminister_details($user['friconn_id']);

            if ($user['approved'] === 0) {
                return array(
                    'status' => "success",
                    'message' => "One more step to go, please verify your email address.",
                    'status_code' => $this->status_code['ok'],
                    'data' => array_merge($user, $eduminister_details)
                );
            }

            return array(
                'status' => "success",
                'message' => "Login successful.",
                'status_code' => $this->status_code['ok'],
                'data' => array_merge($user, $eduminister_details)
            );
        }


        public function create_account($details)
        {
            try {
                if ($this->db->insert('users', $details)) {
                    if ($this->db->insert('eduministers_profile', array('friconn_id' => $details['friconn_id']))) {
                        $this->db->where(["friconn_id" => $details['friconn_id']]);
                        $user = $this->db->get('users')->row_array();
                        if ($user) {
                            $other_details = $this->_get_eduminister_details($details['friconn_id']);
                            return array(
                                'status' => "success",
                                'message' => "One more step to go, please verify your email address.",
                                'status_code' => $this->status_code['created'],
                                'data' => array_merge($user, $other_details)
                            );
                        } else {
                            return array(
                                'status' => "error",
                                'message' => "Opps! The server has encountered a temporary error. Please try again later",
                                'status_code' => $this->status_code['internalServerError']
                            );
                        }
                    } else {
                        return array(
                            'status' => "error",
                            'message' => "Opps! The server has encountered a temporary error. Please try again later",
                            'status_code' => $this->status_code['internalServerError']
                        );
                    }
                } else {
                    return array(
                        'status' => "error",
                        'message' => "Opps! The server has encountered a temporary error. Please try again later",
                        'status_code' => $this->status_code['internalServerError']
                    );
                }
            } catch (\Throwable $th) {
                return array(
                    'status' => "error",
                    'message' => "Opps! The server has encountered a temporary error. Please try again later",
                    'status_code' => $this->status_code['internalServerError']
                );
            };
        }

        public function get_last_user_id()
        {
            $users = $this->db->select('id')->order_by('id', "desc")->limit(1)->get('users')->row();
            return ($users->id + 1);
        }

        public function get_eduministers(){
            $role_id = $this->fn_model->get_user_role_id('eduminister');

            $this->db->select('friconn_id,role_id,last_name,other_names,email,profile_image,created_at');$this->db->select('friconn_id,role_id,last_name,other_names,email,profile_image,created_at');
            $profiles = $this->db->get_where('users',['role_id' => $role_id])->result();
            foreach ($profiles as $profile) {
                $profile->profile = $this->_get_eduminister_details($profile->friconn_id);
            }
            return $profiles;
        }

        public function get_eduminister($friconn_id){
            $role_id = $this->fn_model->get_user_role_id('eduminister');
            $this->db->select('friconn_id,role_id,last_name,other_names,email,profile_image,created_at');
            $eduminister = $this->db->get_where('users',['friconn_id' => $friconn_id,'role_id' => $role_id])->row_array();
            
            if ($eduminister['role_id'] == $role_id) {
                $eduminister_details = $this->_get_eduminister_details($friconn_id);
                return array_merge($eduminister, $eduminister_details);
            }
            return null;
        }

        public function get_eduminister_points($friconn_id){
            $this->db->select('points');
            $eduminister_points = $this->db->get_where('eduministers_profile',['friconn_id' => $friconn_id])->row_array();
            
            if ($eduminister_points) {
                return $eduminister_points['points'];
            }
            return null;
        }

        private function _get_eduminister_details($friconn_id)
        {
            $this->db->select('*');
            $query = $this->db->get_where('eduministers_profile', array('friconn_id' => $friconn_id));
            $result = $query->row_array();
            $result['employment_status'] = $this->fn_model->get_user_employment_status($result['employment_status_id']);
            $result['gender'] = $this->fn_model->get_user_gender($result['gender_id']);
            $result['state'] = $this->fn_model->get_user_state($result['state_id']);
            return $result;
        }

        public function update_eduminister_profile($data)
        {
            $update_profile = $this->db->update('eduministers_profile',$data,['friconn_id' => $data['friconn_id']]);
            if ($update_profile) {
                return true;
            }
            return false;
        }

        public function update_eduminister_points($data)
        {
            $update_points = $this->db->update('eduministers_profile',$data,['friconn_id' => $data['friconn_id']]);
            if ($update_points) {
                return $this->get_eduminister_points($data['friconn_id']);
            }
            return false;
        }

        public function get_eduminister_payouts($friconn_id){
            $this->db->select('*');
            $eduminister_payouts = $this->db->order_by('id', "desc")->get_where('eduminister_payouts',['friconn_id' => $friconn_id])->result();

            
            if ($eduminister_payouts) {                
                foreach ($eduminister_payouts as $eduminister_payout) {
                    $conversion_rate = $this->fn_model->get_conversion_rate($eduminister_payout->conversion_rate_id);
                    $eduminister_payout->naira_per_point = $conversion_rate['naira_per_point'];
                }
                return $eduminister_payouts;
            }
            return null;
        }

        public function get_eduministers_payouts(){
            $this->db->select('*');
            $eduministers_payouts = $this->db->order_by('id', "desc")->get('eduminister_payouts')->result();

            foreach ($eduministers_payouts as $eduministers_payout) {
                $user = $this->fn_model->get_user_via_friconn_id($eduministers_payout->friconn_id);
                $eduministers_payout->eduminister = $user['last_name']. ' '.$user['other_names'];

                $conversion_rate = $this->fn_model->get_conversion_rate($eduministers_payout->conversion_rate_id);
                $eduministers_payout->naira_per_point = $conversion_rate['naira_per_point'];
            }

            
            if ($eduministers_payouts) {
                return $eduministers_payouts;
            }
            return null;
        }

        public function request_payout($data){
            if ($this->db->insert('eduminister_payouts',$data)) {
                return true;
            }
            return false;
        }


        public function update_balance($data)
        {
            $update_balance = $this->db->update('eduministers_profile',$data,['friconn_id' => $data['friconn_id']]);
            if ($update_balance) {
                return true;
            }
            return false;
        }


        public function get_eduministers_courses(){
            $this->db->select('*');
            $eduministers_courses = $this->db->order_by('id', "desc")->get('eduminister_courses')->result();

            if ($eduministers_courses) {
                foreach ($eduministers_courses as $eduministers_course) {
                    $user = $this->fn_model->get_user_via_friconn_id($eduministers_course->friconn_id);
                    $eduministers_course->eduminister = $user['last_name']. ' '.$user['other_names'];

                    $course = $this->fn_model->get_user_course($eduministers_course->course_id);
                    $eduministers_course->course = $course;
                }

                return $eduministers_courses;
            }
            return null;
        }

        public function get_eduminister_courses($friconn_id){
            $this->db->select('*');
            $this->db->where(['friconn_id' => $friconn_id]);
            $eduminister_courses = $this->db->order_by('id', "desc")->get('eduminister_courses')->result();

            if ($eduminister_courses) {
                foreach ($eduminister_courses as $eduminister_course) {
                    $user = $this->fn_model->get_user_via_friconn_id($eduminister_course->friconn_id);
                    $eduminister_course->eduminister = $user['last_name']. ' '.$user['other_names'];

                    $course = $this->fn_model->get_user_course($eduminister_course->course_id);
                    $eduminister_course->course = $course;
                }

                return $eduminister_courses;
            }
            return null;
        }

        public function check_eduminister_course($data){
            $this->db->select('id');
            $this->db->where(['course_id' => $data['course_id'],'friconn_id' =>$data['friconn_id']]);
            $eduministers_course = $this->db->get('eduminister_courses')->num_rows();
            if ($eduministers_course > 0) {
                return true;
            }
            return false;
        }

        public function add_eduminister_course($data){
            if ($this->db->insert('eduminister_courses',$data)) {
                $course = $this->get_eduminister_last_course($data['friconn_id']);
                return $course;
            }
            return false;
        }

        public function get_eduminister_last_course($friconn_id){
            $this->db->select('*');
            $this->db->where(['friconn_id' => $friconn_id]);
            $eduminister_course = $this->db->order_by('id', "desc")->limit(1)->get('eduminister_courses')->row_array();

            if ($eduminister_course) {
                $course = $this->fn_model->get_user_course($eduminister_course->course_id);
                $eduminister_course->course = $course;

                return $eduminister_course;
            }
            return null;
        }

        public function get_eduminister_questions($friconn_id){
            $this->db->select('*');
            $this->db->where(['friconn_id' => $friconn_id]);
            $eduminister_questions = $this->db->order_by('id', "desc")->get('questions')->result();

            if ($eduminister_questions) {
                foreach ($eduminister_questions as $eduminister_question) {
                    $user = $this->fn_model->get_user_via_friconn_id($eduminister_question->friconn_id);
                    $eduminister_question->eduminister = $user['last_name']. ' '.$user['other_names'];

                    $eduminister_question->question = substr($eduminister_question->question, 0,119);

                    // $course = $this->fn_model->get_user_course($eduminister_question->course_id);
                    // $eduministers_question->course = $course;
                }

                return $eduminister_questions;
            }
            return null;
        }

        public function get_eduminister_answers($friconn_id){
            $this->db->select('*');
            $this->db->where(['friconn_id' => $friconn_id]);
            $eduminister_answers = $this->db->order_by('id', "desc")->get('question_answers')->result();

            if ($eduminister_answers) {
                foreach ($eduminister_answers as $eduminister_answer) {
                    $user = $this->fn_model->get_user_via_friconn_id($eduminister_answer->friconn_id);
                    $eduminister_answer->eduminister = $user['last_name']. ' '.$user['other_names'];

                    $question = $this->fn_model->get_user_question($eduminister_answer->question_id);
                    $eduminister_answer->question = $question;
                }

                return $eduminister_answers;
            }
            return null;
        }

    }
