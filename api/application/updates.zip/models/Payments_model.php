<?php
class Payments_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }

    public function add_payment($data){
        if ($this->db->insert('payments',$data)) {
            $payment = $this->get_last_payment();
            return $payment;
        }
        return false;
    }

    public function get_payment($id){
        $this->db->select('*');
        $payment = $this->db->get_where('payments',['id' => $id])->row_array();
        if ($payment) {
            $user = $this->fn_model->get_user_via_friconn_id($payment['friconn_id']);
            $payment['user'] = $user['last_name'] .' '. $user['other_names'];

            $plan = $this->fn_model->get_user_plan($payment['plan_id']);
            $payment['plan'] = $plan;
            return $payment;
        }
        return null;
    }

    public function get_payments(){
        $this->db->select('*');
        $payments = $this->db->order_by('id','desc')->get('payments')->result();

        if ($payments) {
            foreach ($payments as $payment) {
                $user = $this->fn_model->get_user_via_friconn_id($payment->friconn_id);
                $payment->user = $user['last_name'] .' '. $user['other_names'];

                $plan = $this->fn_model->get_user_plan($payment->plan_id);
                $payment->plan = $plan;
            }
            return $payments;
        }
        return null;
    }

    public function get_last_payment(){
        $this->db->select('*');
        $payment = $this->db->order_by('id', "desc")->limit(1)->get('payments')->row_array();
        if ($payment) {
            return $payment;
        }
        return null;
    }

    public function check_payment_existence($data)
    {
        $this->db->select('id');
        $payment = $this->db->get_where('payments',['txt_ref' => $data['txt_ref']])->num_rows();
        if ($payment > 0) {
            return true;
        }
        return false;
    }
}
