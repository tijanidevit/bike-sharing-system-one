<?php
class plans_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }

    public function add_plan($data){
        if ($this->db->insert('plans',$data)) {
            $plan = $this->get_last_plan();
            return $plan;
        }
        return false;
    }
    
    public function get_plan($id){
        $this->db->select('*');
        $plan = $this->db->get_where('plans',['id' => $id])->row_array();
        if ($plan) {
            $plan['plan_features'] = $this->get_plan_features($id);
            return $plan;
        }
        return null;
    }

    public function get_plans(){
        $this->db->select('*');
        $plans = $this->db->order_by('id','desc')->get('plans')->result();

        if ($plans) {
            foreach ($plans as $plan) {
                $plan->plan_features = $this->get_plan_features($plan->id);
            }
            return $plans;
        }
        return null;
    }

    public function get_last_plan(){
        $this->db->select('*');
        $plan = $this->db->order_by('id', "desc")->limit(1)->get('plans')->row_array();
        if ($plan) {
            return $plan;
        }
        return null;
    }

    public function check_plan_existence($data)
    {
        $this->db->select('id');
        $plan = $this->db->get_where('plans',['plan' => $data['plan']])->num_rows();
        if ($plan > 0) {
            return true;
        }
        return false;
    }

    public function get_plan_features($id){
        $this->db->select('*');
        $this->db->where(['plan_id' => $id]);
        $plan_features = $this->db->order_by('id', "desc")->get('plan_features')->result();

        if ($plan_features) {
            return $plan_features;
        }
        return null;
    }

    public function add_plan_feature($data){
        if ($this->db->insert('plan_features',$data)) {
            $plan = $this->get_last_feature($data['plan_id']);
            return $plan;
        }
        return false;
    }


    public function check_plan_feature_existence($data)
    {
        $this->db->select('id');
        $feature = $this->db->get_where('plan_features',['plan_id' => $data['plan_id'],'feature' => $data['feature']])->num_rows();
        if ($feature > 0) {
            return true;
        }
        return false;
    }

    public function get_last_feature($plan_id){
        $this->db->select('*');
        $this->db->where(['plan_id' => $plan_id]);
        $plan_feature = $this->db->order_by('id', "desc")->limit(1)->get('plan_features')->row_array();

        if ($plan_feature) {

            return $plan_feature;
        }
        return null;
    }
}
