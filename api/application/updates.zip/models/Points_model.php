<?php
class Points_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
        $this->load->model('fn_model');
        $this->status_code  = get_response_status_code();
    }

    public function add_charging_points($data){
        if ($this->db->insert('charging_points',$data)) {
            $points = $this->get_last_charging_points();
            return $points;
        }
        return false;
    }
    
    public function get_single_charging_points($id){
        $this->db->select('*');
        $points = $this->db->get_where('charging_points',['id' => $id])->row_array();
        if ($points) {
            return $points;
        }
        return null;
    }

    public function get_all_charging_points(){
        $this->db->select('*');
        $charging_points = $this->db->order_by('id','desc')->get('charging_points')->result();

        if ($charging_points) {
            return $charging_points;
        }
        return null;
    }

    public function get_last_charging_points(){
        $this->db->select('*');
        $points = $this->db->order_by('id', "desc")->limit(1)->get('charging_points')->row_array();
        if ($points) {
            return $points;
        }
        return null;
    }   


    public function add_earning_points($data){
        if ($this->db->insert('earning_points',$data)) {
            $points = $this->get_last_earning_points();
            return $points;
        }
        return false;
    }
    
    public function get_single_earning_points($id){
        $this->db->select('*');
        $points = $this->db->get_where('earning_points',['id' => $id])->row_array();
        if ($points) {
            return $points;
        }
        return null;
    }

    public function get_all_earning_points(){
        $this->db->select('*');
        $earning_points = $this->db->order_by('id','desc')->get('earning_points')->result();

        if ($earning_points) {
            return $earning_points;
        }
        return null;
    }

    public function get_last_earning_points(){
        $this->db->select('*');
        $points = $this->db->order_by('id', "desc")->limit(1)->get('earning_points')->row_array();
        if ($points) {
            return $points;
        }
        return null;
    }
}
